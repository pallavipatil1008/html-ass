jQuery(document).ready(function() {
    // Wait for the DOM to be ready
$(function() {

$("form[name='registration']").validate({

rules: {
subject: "required",
message: "required",
email: {
required: true,

email: true
},
password: {
required: true,
minlength: 5
}
},

// Specify validation error messages
messages: {
subject: "Please enter your subject",
message: "Please enter your message",
password: {
required: "Please provide a password",
minlength: "Your password must be at least 5 characters long"
},
email: "Please enter a valid email address"
},

submitHandler: function(form) {
input.onchange();
$(".error").parent().css({"color": "red", "border": "2px solid red"});

}
});
});
    $(window).scroll(function() {
if ($(".navbar").offset().top > 50) {
$(".navbar-fixed-top").addClass("top-nav-collapse");
} else {
$(".navbar-fixed-top").removeClass("top-nav-collapse");
}
});
    $('#bridgeSlide').bridgeSlide({
        width: 500,
        visibleItems: 1,
        itemMargin: 20
    });

   
    $('.carousel').carousel({
        interval: 6000
        });
        $('#media').carousel({
            pause: true,
            interval: false,
        });
});